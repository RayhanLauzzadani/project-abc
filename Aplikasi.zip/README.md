## Nextshop Ecommerce

### Aplikasi toko online stack Laravel & vue

## Demo

[Nextshop Home](https://nextshop.my.id)

## Installasi

Lihat di panduan installasi

## Development

Lihat di panduan development


## Teknologi

- [Laravel 8](https://laravel.com/)
- [VueJs](https://vuejs.org/)
- [Quasar Framework](https://quasar.dev/)
