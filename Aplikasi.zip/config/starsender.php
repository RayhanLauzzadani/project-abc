<?php

return [
  'apikey' => env('STARSENDER_API_KEY', '83a5ac72d6a16013877044b6cbc12a56e951b04d'),
  'endpoint' => env('STARSENDER_ENDPOINT', 'https://starsender.online/api')
];