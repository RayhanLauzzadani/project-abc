<?php

namespace Silehage\Rajaongkir\Facades;

use Illuminate\Support\Facades\Facade;

class Rajaongkir extends Facade
{
  public static function getFacadeAccessor()
  {
    return 'Rajaongkir';
  }
}

?>