import { Loading, QSpinnerGears } from 'quasar'

Loading.setDefaults({
  spinner: QSpinnerGears,
})