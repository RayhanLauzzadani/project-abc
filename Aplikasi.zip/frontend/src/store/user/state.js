export default function () {
  return {
    loggedUser: false,
    user: null,
  }
}
