export default function () {
  return {
    blocks: {
      banner: [],
      partner: [],
      featured: [],
      ready: false,
      available: true
    },
    admin_data: {
      data: [],
      ready: false,
      available: true
    }
  }
}
