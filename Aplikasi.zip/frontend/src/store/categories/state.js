export default function () {
  return {
    categories: {
      data: [],
      ready: false,
      available: true
    },
    all_categories: {
      data: [],
      ready: false,
      available: true
    },
  }
}
