export default function () {
  return {
    banks: {
      data: [],
      ready: true,
      available: false
    }
  }
}
