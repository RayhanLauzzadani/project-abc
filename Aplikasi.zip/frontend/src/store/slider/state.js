export default function () {
  return {
    sliders: {
      data: [],
      ready: false,
      available: true
    }
  }
}
