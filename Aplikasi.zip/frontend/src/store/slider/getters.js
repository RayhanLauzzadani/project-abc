export const sliderCount = (state) => {
  return state.sliders.data.length
}