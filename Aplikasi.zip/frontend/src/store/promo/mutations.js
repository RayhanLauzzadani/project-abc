export function SET_PROMOS (state, payload) {
  state.promos = payload
}
export function SET_PRODUCT_PROMO (state, payload) {
  state.products = payload
}