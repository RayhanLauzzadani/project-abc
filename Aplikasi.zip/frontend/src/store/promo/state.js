export default function () {
  return {
    promos: [],
    products: []
  }
}
