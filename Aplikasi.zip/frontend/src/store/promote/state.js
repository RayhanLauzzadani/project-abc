export default function () {
  return {
    promotes: [],
    products: []
  }
}
