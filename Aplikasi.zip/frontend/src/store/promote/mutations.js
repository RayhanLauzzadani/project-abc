export function SET_PROMOTES (state, payload) {
  state.promotes = payload
}
export function SET_PRODUCT_PROMO (state, payload) {
  state.products = payload
}