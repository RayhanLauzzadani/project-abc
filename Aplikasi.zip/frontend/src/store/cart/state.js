export default function () {
  return {
    carts: [],
  }
}
