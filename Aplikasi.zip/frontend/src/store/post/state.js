export default function () {
  return {
    posts: {
      data: [],
      ready: false,
      available: true
    },
    listing_posts: {
      data: [],
      ready: false,
      available: true
    },
    initialPost: []
  }
}
